# MSI Parcel Driver v0.1
Flutter source for Android + iOS.

Implemented now:
- MSI Parcel branding/logo
- Driver phone sign-in screen (UI foundation)
- Online/offline state
- Assigned delivery list
- Delivery detail + COD amount
- Status flow: assigned -> accepted -> picked_up -> out_for_delivery -> delivered
- OTP completion foundation (demo OTP 1234)

Next integration:
Firebase Auth, Firestore, FCM, Google Maps, geolocator/background location, live driver location, admin assignment.

Run on a machine with Flutter SDK:
flutter pub get
flutter run

This environment did not have Flutter SDK installed, so source was generated but no APK/IPA is falsely claimed as built/tested here.
