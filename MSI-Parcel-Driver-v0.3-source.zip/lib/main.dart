import 'package:flutter/material.dart';
import 'core/theme.dart';
import 'screens/splash_screen.dart';

void main() => runApp(const MsiParcelDriverApp());

class MsiParcelDriverApp extends StatelessWidget {
  const MsiParcelDriverApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'MSI Parcel Driver',
    theme: AppTheme.light,
    home: const SplashScreen(),
  );
}
