import 'package:flutter/material.dart';
class AppTheme {
  static const purple = Color(0xFF5B168B);
  static const teal = Color(0xFF00A6A6);
  static ThemeData get light => ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: purple, primary: purple, secondary: teal),
    useMaterial3: true,
    scaffoldBackgroundColor: const Color(0xFFF7F7FB),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: purple),
    inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
  );
}
