class OrderStatus {
  static const assigned = 'assigned';
  static const accepted = 'accepted';
  static const pickedUp = 'picked_up';
  static const outForDelivery = 'out_for_delivery';
  static const delivered = 'delivered';

  static const allowedTransitions = <String, Set<String>>{
    assigned: {accepted},
    accepted: {pickedUp},
    pickedUp: {outForDelivery},
    outForDelivery: {delivered},
    delivered: {},
  };

  static bool canMove(String from, String to) => allowedTransitions[from]?.contains(to) ?? false;
}
