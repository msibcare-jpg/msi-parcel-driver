import '../models/delivery_job.dart';
class DriverRepository {
  Future<List<DeliveryJob>> assignedJobs() async => const [
    DeliveryJob(id:'MSI-1001', pickup:'Al Safa, Jeddah', dropoff:'Al Hamra, Jeddah', customerName:'Test Customer', customerPhone:'+966 5X XXX XXXX', codAmount:75),
  ];
  Future<void> setOnline(bool online) async {}
  Future<void> updateStatus(String orderId, String status) async {}
  Future<bool> verifyOtp(String orderId, String otp) async => otp == '1234';
}
