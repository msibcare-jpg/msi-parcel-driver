import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/delivery_job.dart';

class FirestoreDriverRepository {
  final _db = FirebaseFirestore.instance;
  Stream<List<DeliveryJob>> assignedJobs(String driverId) => _db.collection('orders')
      .where('driverId', isEqualTo: driverId)
      .where('status', whereIn: ['assigned','accepted','picked_up','out_for_delivery'])
      .snapshots().map((s) => s.docs.map((d) {
        final x=d.data();
        return DeliveryJob(
          id:d.id,
          pickup:(x['pickupAddress']??'').toString(),
          dropoff:(x['dropoffAddress']??'').toString(),
          customerName:(x['receiverName']??'').toString(),
          customerPhone:(x['receiverPhone']??'').toString(),
          status:(x['status']??'assigned').toString(),
          codAmount:((x['codAmount']??0) as num).toDouble(),
        );
      }).toList());

  Future<void> updateStatus(String orderId, String status, String driverId) async {
    final ref=_db.collection('orders').doc(orderId);
    await _db.runTransaction((tx) async {
      final snap=await tx.get(ref);
      if(!snap.exists) throw Exception('Order not found');
      if(snap.data()?['driverId'] != driverId) throw Exception('Order is not assigned to this driver');
      tx.update(ref, {'status':status,'updatedAt':FieldValue.serverTimestamp()});
      tx.set(ref.collection('events').doc(), {
        'type':'status_changed','status':status,'actorId':driverId,'createdAt':FieldValue.serverTimestamp()
      });
    });
  }

  Future<bool> verifyOtp(String orderId,String otp,String driverId) async {
    final ref=_db.collection('orders').doc(orderId);
    final snap=await ref.get();
    final data=snap.data();
    if(data==null || data['driverId']!=driverId) return false;
    return (data['deliveryOtp']??'').toString()==otp.trim();
  }
}
