import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

class LiveLocationService {
  StreamSubscription<Position>? _sub;
  Future<bool> ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) return false;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    return p == LocationPermission.always || p == LocationPermission.whileInUse;
  }

  Future<void> start(String driverId) async {
    if (!await ensurePermission()) return;
    await _sub?.cancel();
    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 15),
    ).listen((p) async {
      await FirebaseFirestore.instance.collection('drivers').doc(driverId).set({
        'location': GeoPoint(p.latitude, p.longitude),
        'heading': p.heading,
        'speedMps': p.speed,
        'lastLocationAt': FieldValue.serverTimestamp(),
        'isOnline': true,
      }, SetOptions(merge: true));
    });
  }

  Future<void> stop(String driverId) async {
    await _sub?.cancel();
    _sub = null;
    await FirebaseFirestore.instance.collection('drivers').doc(driverId).set({
      'isOnline': false,
      'lastLocationAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}
