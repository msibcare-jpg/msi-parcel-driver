import 'dart:async';
import 'package:flutter/material.dart';
import 'login_screen.dart';
class SplashScreen extends StatefulWidget { const SplashScreen({super.key}); @override State<SplashScreen> createState()=>_SplashScreenState(); }
class _SplashScreenState extends State<SplashScreen>{
 @override void initState(){super.initState();Timer(const Duration(seconds:2),(){if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const LoginScreen()));});}
 @override Widget build(BuildContext context)=>Scaffold(body:Center(child:Image.asset('assets/images/msi_parcel_logo.png',width:260)));
}
