import 'package:flutter/material.dart';
import 'driver_home_screen.dart';
class LoginScreen extends StatelessWidget { const LoginScreen({super.key});
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Driver Sign in')),body:Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const TextField(keyboardType:TextInputType.phone,decoration:InputDecoration(labelText:'Saudi mobile number',prefixText:'+966 ')),const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const DriverHomeScreen())),child:const Text('Continue')))])));
}
