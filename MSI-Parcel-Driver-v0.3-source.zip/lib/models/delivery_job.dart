class DeliveryJob {
  final String id, pickup, dropoff, customerName, customerPhone;
  final double codAmount;
  final String status;
  const DeliveryJob({required this.id, required this.pickup, required this.dropoff, required this.customerName, required this.customerPhone, required this.codAmount, this.status='assigned'});
}
