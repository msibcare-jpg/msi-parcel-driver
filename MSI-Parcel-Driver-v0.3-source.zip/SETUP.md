# MSI Parcel Driver v0.2 setup
1. Create/choose Firebase project.
2. Add Android and iOS apps in Firebase console.
3. Run `flutterfire configure` to generate `lib/firebase_options.dart` and platform config files.
4. Enable Phone Authentication and Firestore.
5. Deploy `firestore.rules`.
6. Enable Maps SDK for Android/iOS and add API keys to AndroidManifest.xml / AppDelegate.
7. Add Android location permissions and iOS NSLocationWhenInUseUsageDescription / background location settings before production tracking.
8. Run `flutter pub get` then `flutter run`.

This package intentionally does not contain private Firebase/Google API keys.
