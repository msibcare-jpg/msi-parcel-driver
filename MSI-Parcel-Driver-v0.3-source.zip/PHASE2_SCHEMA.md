# MSI Parcel scalable data model
Collections: users, drivers, orders, order_events, driver_locations, service_zones, pricing_rules, cod_transactions.

`service_zones` controls launch geography. Jeddah is a configuration value, not a hard-coded product limitation, so Saudi-wide/international expansion does not require an app rewrite.

Order lifecycle: assigned -> accepted -> picked_up -> out_for_delivery -> delivered.
